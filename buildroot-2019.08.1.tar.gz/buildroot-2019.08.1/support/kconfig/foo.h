#ifndef __KCONFIG_FOO_H
#define __KCONFIG_FOO_H

#ifndef __APPLE__
#include <features.h>
#endif
#include <limits.h>

#ifndef PATH_MAX
#define PATH_MAX 1024
#endif
#endif /* __KCONFIG_FOO_H */
